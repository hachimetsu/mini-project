// let {default: Create } = await import('prompt-sync');let prompt = Create();
let Error = [
    "few arg !",
    "mod not match identifiers",
    "mod not defined",
    "Identifier not "
]
let consoleDiv = document.getElementById("user-output");
export const printf = (...args) => {
    let Output;
    if (args.length != 0) Output = args.shift();
    args.forEach(e => { Output = Output.replace(/%[a-zA-Z]/i, e) });
    Output = Output.replace(/%[a-zA-Z]/i, null);
    let c = console.log;
    // console.log(Output) // use for JS-console
    consoleDiv.innerHTML += Output + "<br>"; // use for div-console
};
export const scanf = (...args) => {
    let m = ["%d", "%f", "%c", "%s"];
    let result = null;
    let mod = args.shift();
    if (typeof mod === "undefined") {
        result = "few arg !";
    }
    // if (args.length === 0){
    //     result = "very few arguments";
    // } else if(typeof args[0] !== "string"){
    //     result = "1st argument must be string type with modefier specified";
    // } else if (args[0].length === 0) {
    //     result = "empty modefier argument !";
    // } else{
    //     let modefiers = args.shift().match(/%[a-zA-Z]/g);
    //     result = modefiers;
    //     if(modefiers.length !== args.length){
    //         result = "number of modefier provided not match the no of Identifiers profided";
    //     }
    //     else if(modefiers.every(e => {return e in m}) === false){
    //         result = "every";
    //     }
    // }
    console.log(result);
}
import { init } from './init.js';init();
await $include("stdio");
printf("enter no", 1);
// Console.in = (msg) => {
//     let newDiv = document.createElement("div");
//     let p = window.prompt;
//     newDiv.setAttribute('id','console-in');
//     let FocusInHandler = () => { newDiv.contentEditable = true }
//     newDiv.addEventListener('focus', () => { FocusInHandler()});
//     newDiv.addEventListener('focusout', () => { newDiv.contentEditable = false; newDiv.removeEventListener('focusin', FocusInHandler)});
//     consoleDiv.appendChild(newDiv);
//     window.prompt = function (message) {
//         // Set the message as the content of the promptDiv element
//         newDiv.innerHTML = message;
//         // Make the promptDiv element visible
//         newDiv.style.display = "block";
//         newDiv.focus();
//         // Wait for the user to enter a value and click the OK button
//         return new Promise(function (resolve) {
//             newDiv.addEventListener("keydown", function (event) {
//                 if (event.key === "Enter") {
//                     // Get the value from the promptDiv element
//                     var value = this.value;

//                     // Hide the promptDiv element
//                     this.style.display = "none";

//                     // Resolve the promise with the value
//                     resolve(value);
//                 }
//             });
//         });
//     };
//     // Use the window.prompt function to get a value from the user
//     let res = window.prompt(msg).then((value) => { return value });
//     window.prompt = p;
//     return res;
// }
// Console.in = (msg) => {
//     let newDiv = document.createElement("div");
//     newDiv.contentEditable = true;
//     // let FocusInHandler = () => { newDiv.textContent = msg;  }
//     newDiv.addEventListener("focus", function () {this.setSelectionRange(this.innerHTML.length, this.innerHTML.length);});
//     consoleDiv.appendChild(newDiv);
//     let p = window.prompt;
//     window.prompt = function (message) {
//     //Set the message as the content of the promptDiv element
//         newDiv.innerHTML = ' ';
//         newDiv.insertAdjacentText('beforebegin', msg);
//         // Make the promptDiv element visible
//         newDiv.style.display = "block";
//         newDiv.focus();
//         // Wait for the user to enter a value and click the OK button
//         return new Promise(function (resolve) {
//             newDiv.addEventListener("keydown", function (event) {
//                 if (event.key === "Enter") {
//                     // Get the value from the promptDiv element
//                     var value = this.value;

//                     // Hide the promptDiv element
//                     this.style.display = "none";

//                     // Resolve the promise with the value
//                     resolve(value);
//                 }
//             });
//         });
//     };
//     // Use the window.prompt function to get a value from the user
//     let res;
//     window.prompt(msg).then((value) => { res = value });
//     window.prompt = p;
//     return res;
// }
// consoleDiv.addEventListener("focus", function () {
    
// });
// consoleDiv.addEventListener("focusout", function () {
// });
// consoleDiv.focus()
// let a = Console.in("Enter a: ");
// Console.out("a: ", a);
// var userInput = prompt("Enter a");
// consoleDiv.innerHTML = userInput;
// let a = prompt("Enter a : ");
// console.log("a : ", a);
// await $include("stdio");
// console.log(typeof "dasd")
// scanf();
// console.log("".length)
// function change(a){
//     a.pop();
//     a.push(2);
//     console.log(a)
// }
// let a = [1];
// change(a)
// console.log(a)

// eval(`
// var t = 1;
// console.log(window)
// `);





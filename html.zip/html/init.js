export const init = async () => {
    window["$include"] = async (name) => { const HeaderFile = await import(`./headerFiles/${name}.js`); Object.keys(HeaderFile).forEach(async (mod) => await (window[mod] = HeaderFile[mod])) }
//comment bellow line to use JS on console
    console.log = function (message) { document.getElementById("user-output")};
}